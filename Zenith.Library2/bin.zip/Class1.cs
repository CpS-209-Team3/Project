﻿using System;

namespace Zenith.Library2
{
    public class Class1
    {
    }
}
