﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zenith.Library
{
    class Player : Ship
    {
        public Player(Vector position)
            : base(position)
        {

        }
    }
}
