﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zenith.Library
{
    class Boss4 : Enemy
    {
        public override void Loop() { }

        public Boss4(Vector position)
            : base(position) { }
    }
}
