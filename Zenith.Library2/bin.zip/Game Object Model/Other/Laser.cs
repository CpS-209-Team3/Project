﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Zenith.Library
{
    class Laser : GameObject
    {
        private int damage;
        private bool isFromPlayer;

        public bool IsFromPlayer
        {
            get { return isFromPlayer; }
        }

        public int Damage
        {
            get { return damage; }
        }

        public override void OnCollision(GameObject gameObject)
        {
            // only does damage to the opponenet
            if ((isFromPlayer && gameObject is Enemy) || (!isFromPlayer && !(gameObject is Enemy)))
            {
                Destroy = true;
            }
        }

        public override void Loop() { }

        public Laser(bool isFromPlayer, Vector position, Vector velocity, int damage)
            : base(position)
        {
            this.isFromPlayer = isFromPlayer;
            this.velocity = velocity;
            this.damage = damage;
        }

        public override string Serialize()
        {
            return base.Serialize() + ',' + isFromPlayer.ToString() + ',' + damage.ToString();
        }

        public override void Deserialize(string saveInfo)
        {
            int i = 0;
            int index = IndexOfNthOccurance(saveInfo, ",", 5);

            string gameObjectSaveInfo = saveInfo.Substring(0, index);
            string[] laserSaveInfo = saveInfo.Substring(index, saveInfo.Length - index).Split(',');

            base.Deserialize(gameObjectSaveInfo);

            foreach (PropertyInfo property in typeof(Ship).GetProperties())
            {
                property.SetValue(this, laserSaveInfo[i]);
                i++;
            }
        }
    }
}
